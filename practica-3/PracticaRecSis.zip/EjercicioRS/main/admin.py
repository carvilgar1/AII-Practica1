from django.contrib import admin
from main.models import Libro,Rating,Idiomas

# admin.site.register(UserInformation)
admin.site.register(Libro)
admin.site.register(Rating)
admin.site.register(Idiomas)